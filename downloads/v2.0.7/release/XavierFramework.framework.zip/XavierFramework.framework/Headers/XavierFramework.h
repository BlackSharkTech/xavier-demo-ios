//
//  XavierFramework.h
//  XavierFramework
//
//  Created by Duke Hallman on 10/19/18.
//  Copyright © 2018 Blackshark Tech. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for XavierFramework.
FOUNDATION_EXPORT double XavierFrameworkVersionNumber;

//! Project version string for XavierFramework.
FOUNDATION_EXPORT const unsigned char XavierFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <XavierFramework/PublicHeader.h>


